package Patient;

/*
 * Class: CMSC203
 * Instructor: Prof. Ahmed Tarek
 * Description: A class representing a medical procedure performed on a patient.
 * Due: MM/DD/YYYY
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source. I have not given my code to any student.
 * Print your Name here: Bereket Asmerom
 */

public class Procedure {
    // Instance variables
    private String procName;
    private String procDate;
    private String docName;
    private double procCost;

    public Procedure() {
    }

    public Procedure(String procName, String procDate) {
        this.procName = procName;
        this.procDate = procDate;
    }

    public Procedure(String procName, String procDate, String docName, double procCost) {
        this.procName = procName;
        this.procDate = procDate;
        this.docName = docName;
        this.procCost = procCost;
    }

    public String getProcName() {
        return procName;
    }

    public String getProcDate() {
        return procDate;
    }

    public String getDocName() {
        return docName;
    }

    public double getProcCost() {
        return procCost;
    }

    public void setProcName(String procName) {
        this.procName = procName;
    }

    public void setProcDate(String procDate) {
        this.procDate = procDate;
    }

    public void setDocName(String docName) {
        this.docName = docName;
    }

    public void setProcCost(double procCost) {
        this.procCost = procCost;
    }

    @Override
    public String toString() {
        return "Procedure Info:\n" + 
               "\tName: " + procName + "\n" +
               "\tDate: " + procDate + "\n" +
               "\tDoctor: " + docName + "\n" +
               "\tCost: $" + String.format("%.2f", procCost);
    }
}
