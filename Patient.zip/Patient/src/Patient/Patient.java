package Patient;

/*
 * Class: CMSC203
 * Instructor: Prof. Ahmed Tarek
 * Description: A class representing patient details for a healthcare application.
 * Due: MM/DD/YYYY
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source. I have not given my code to any student.
 * Print your Name here: Bereket Asmerom
 */

public class Patient {
    private String givenName;
    private String midName;
    private String familyName;
    private String addressLine;
    private String town;
    private String region;
    private String postalCode;
    private String contactNumber;
    private String contactInEmergency;
    private String emergencyContactPhone;

    public Patient() {
    }

    public Patient(String givenName, String midName, String familyName) {
        this.givenName = givenName;
        this.midName = midName;
        this.familyName = familyName;
    }

    public Patient(String givenName, String midName, String familyName, String addressLine, String town, String region, String postalCode, String contactNumber, String contactInEmergency, String emergencyContactPhone) {
        this.givenName = givenName;
        this.midName = midName;
        this.familyName = familyName;
        this.addressLine = addressLine;
        this.town = town;
        this.region = region;
        this.postalCode = postalCode;
        this.contactNumber = contactNumber;
        this.contactInEmergency = contactInEmergency;
        this.emergencyContactPhone = emergencyContactPhone;
    }

    public String getGivenName() {
        return givenName;
    }

    public String getMidName() {
        return midName;
    }

    public String getFamilyName() {
        return familyName;
    }

    public String getAddressLine() {
        return addressLine;
    }

    public String getTown() {
        return town;
    }

    public String getRegion() {
        return region;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public String getContactInEmergency() {
        return contactInEmergency;
    }

    public String getEmergencyContactPhone() {
        return emergencyContactPhone;
    }

    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public void setMidName(String midName) {
        this.midName = midName;
    }

    public void setFamilyName(String familyName) {
        this.familyName = familyName;
    }

    public void setAddressLine(String addressLine) {
        this.addressLine = addressLine;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public void setContactInEmergency(String contactInEmergency) {
        this.contactInEmergency = contactInEmergency;
    }

    public void setEmergencyContactPhone(String emergencyContactPhone) {
        this.emergencyContactPhone = emergencyContactPhone;
    }

    public String buildFullName() {
        return givenName + " " + midName + " " + familyName;
    }

    // Method to compile full address
    public String buildAddress() {
        return addressLine + ", " + town + ", " + region + " " + postalCode;
    }

    // Method to compile emergency contact info
    public String buildEmergencyContact() {
        return contactInEmergency + " (" + emergencyContactPhone + ")";
    }

    @Override
    public String toString() {
        return "Patient Details:\n" +
               "\tName: " + buildFullName() + "\n" +
               "\tAddress: " + buildAddress() + "\n" +
               "\tContact Number: " + contactNumber + "\n" +
               "\tEmergency Contact: " + buildEmergencyContact();
    }
}
