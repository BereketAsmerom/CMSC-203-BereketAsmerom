package application;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class FXMainPane extends VBox {

    // Task #2: Declare the buttons, label, text field, and HBoxes
    Button btnHello, btnHowdy, btnChinese, btnClear, btnExit, btnFrench;  // Added btnFrench
    Label lblFeedback;
    TextField txtFeedback;
    HBox hBoxButtons, hBoxText;

    // Task #4: Declare an instance of DataManager
    DataManager dataManager;

    // Constructor
    FXMainPane() {
        // Task #2: Instantiate the buttons, label, text field, and HBoxes
        btnHello = new Button("Hello");
        btnHowdy = new Button("Howdy");
        btnChinese = new Button("Chinese");
        btnClear = new Button("Clear");
        btnExit = new Button("Exit");
        btnFrench = new Button("Bonjour");  // New button for French greeting

        lblFeedback = new Label("Feedback:");
        txtFeedback = new TextField();

        hBoxButtons = new HBox();
        hBoxText = new HBox();

        // Task #4: Instantiate DataManager
        dataManager = new DataManager();

        // Task #3: Add components to the HBoxes and VBox
        hBoxButtons.getChildren().addAll(btnHello, btnHowdy, btnChinese, btnClear, btnExit, btnFrench);  // Added btnFrench
        hBoxText.getChildren().addAll(lblFeedback, txtFeedback);

        // Align and set margins
        hBoxButtons.setAlignment(Pos.CENTER);
        hBoxText.setAlignment(Pos.CENTER);
        HBox.setMargin(btnHello, new Insets(10));
        HBox.setMargin(btnHowdy, new Insets(10));
        HBox.setMargin(btnChinese, new Insets(10));
        HBox.setMargin(btnClear, new Insets(10));
        HBox.setMargin(btnExit, new Insets(10));
        HBox.setMargin(btnFrench, new Insets(10));  // Margin for the new button
        HBox.setMargin(lblFeedback, new Insets(10));
        HBox.setMargin(txtFeedback, new Insets(10));

        // Add the HBoxes to the VBox (which is the root container)
        this.getChildren().addAll(hBoxText, hBoxButtons);
        this.setAlignment(Pos.CENTER);  // Center everything in the VBox

        // Task #4: Set button actions
        setButtonActions();  // Make sure this is called
    }

    // Task #4: Inner class to handle button clicks
    private class ButtonHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            Object source = event.getSource();

            if (source == btnHello) {
                txtFeedback.setText(dataManager.getHello());
            } else if (source == btnHowdy) {
                txtFeedback.setText(dataManager.getHowdy());
            } else if (source == btnChinese) {
                txtFeedback.setText(dataManager.getChinese());
            } else if (source == btnFrench) {  // New handler for French button
                txtFeedback.setText(dataManager.getFrench());
            } else if (source == btnClear) {
                txtFeedback.setText("");
            } else if (source == btnExit) {
                Platform.exit();
                System.exit(0);
            }
        }
    }

    // Method to set the button actions
    private void setButtonActions() {
        btnHello.setOnAction(new ButtonHandler());
        btnHowdy.setOnAction(new ButtonHandler());
        btnChinese.setOnAction(new ButtonHandler());
        btnFrench.setOnAction(new ButtonHandler());  // Set action for the new French button
        btnClear.setOnAction(new ButtonHandler());
        btnExit.setOnAction(new ButtonHandler());
    }
}
