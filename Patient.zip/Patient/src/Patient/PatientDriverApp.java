package Patient;

import java.util.Scanner;

/*
 * Class: CMSC203
 * Instructor: Prof. Ahmed Tarek
 * Description: A driver class to create and display Patient and Procedure information.
 * Due: MM/DD/YYYY
 * Platform/compiler: Eclipse
 * I pledge that I have completed the programming assignment independently. I have not copied the code from a student or any source. I have not given my code to any student.
 * Print your Name here: Bereket Asmerom
 */

public class PatientDriverApp {
    
    public static void printPatientInfo(Patient patient) {
        System.out.println(patient.toString());
    }

    public static void printProcedureInfo(Procedure proc) {
        System.out.println(proc.toString());
    }

    public static void computeTotalCost(Procedure proc1, Procedure proc2, Procedure proc3) {
        double totalCost = proc1.getProcCost() + proc2.getProcCost() + proc3.getProcCost();
        System.out.println("Total cost: $" + String.format("%.2f", totalCost));
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        Patient patientA = new Patient("Lucas", "James", "Peterson", "123 Elm St", "Hometown", "TX", "75001", "555-321-7890", "Anna Peterson", "555-654-3210");
        
        Procedure procA = new Procedure("CT Scan", "10/01/2024", "Dr. John Smith", 1200.00);
        Procedure procB = new Procedure("Physical Therapy", "10/02/2024", "Dr. Emily Davis", 800.00);
        Procedure procC = new Procedure("Blood Test", "10/03/2024", "Dr. Michael Lee", 400.00);
        
        printPatientInfo(patientA);
        printProcedureInfo(procA);
        printProcedureInfo(procB);
        printProcedureInfo(procC);
        
        computeTotalCost(procA, procB, procC);
        
        // Display the developer message
        System.out.println("The program was developed by a Student: Bereket Asmerom <09/27/24>");
        
        input.close();
    }
}
